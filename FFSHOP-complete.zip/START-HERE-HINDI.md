# FFSHOP — Cloudflare par ₹0 hosting setup

## Pehle ye samjho

Cloudflare version ka code/build aur local Cloudflare runtime tests pass hain. Abhi aapke Cloudflare account par deploy nahi hua aur aapke phone se real payment test nahi hua. Isliye 100% live guarantee nahi di gayi hai. Free quota ke andar hosting ₹0; internet/phone aapka existing hona chahiye. Paid plan ya domain kharidna zaroori nahi.

Sirf website kholne se bank payment verify nahi hoti. FFSHOP ko **aapke Android phone par merchant business app ki notification** chahiye. App ko internet, notification access aur background mein chalne ki permission chahiye. Phone band/offline hua toh confirmation late ya missing ho sakta hai.

## ZIP mein kya hai?

- **pages-upload.zip** — sirf ye ZIP Cloudflare Pages par upload karni hai.
- **database.sql** — naye D1 database ki tables.
- **maintenance-worker.js** — expiry aur failed shop callbacks ki retry.
- **setup-key.html** — apna private login key banane ka offline page.
- **ffshop-relay-1.3.apk** — Android relay with local notification inspection.
- **source.zip** — editable Cloudflare + Android source, LICENSE aur NOTICE.
- **PAYMENT-LOGIC.md** — exact payment logic aur reference website findings.

**Outer ffshop-cloudflare.zip ko Pages par upload mat karna. Pehle extract karo.**

## 1. Free Cloudflare account

https://dash.cloudflare.com/sign-up par account banao aur email verify karo. Dashboard mein Workers & Pages / Compute aur D1 / Storage & Databases menus dhoondo. UI labels badal sakte hain. Workers **Free** plan use karo. Domain-addition screen aaye toh Workers & Pages section kholo; domain purchase is setup ki requirement nahi hai.

## 2. Apna login key banao

1. Extracted **setup-key.html** ko apne browser mein kholo.
2. **Generate a new key** dabao.
3. **Admin key** ko apne password manager/private note mein save karo. Ye FFSHOP dashboard mein login karne ke kaam aayega.
4. **ADMIN_KEY_HASH** bhi save karo; ye Cloudflare setting mein jayega.
5. Dono ki public screenshot ya GitHub upload mat karna. File khud key save nahi karti, isliye close karne se pehle values save kar lo.

Koi default password nahi hai. Ye page local cryptographic randomness se key banata hai; network request nahi karta. Agar local-file browser mein generation na chale toh source ke CLI setup se key generate karo (cloudflare/README.md).

## 3. D1 database banao

1. Cloudflare → **D1 SQL Database** → **Create database**.
2. Naam **ffshop** rakho.
3. Naye database ka **Console** kholo.
4. **database.sql** ka content paste karke execute karo. Agar console ek baar mein ek statement accept kare, file ke complete SQL statements order mein run karo; `CREATE TRIGGER ... BEGIN ... END;` ko poora ek statement rakho.
5. FFSHOP ki 11 tables dikhni chahiye: `settings`, `sessions`, `limits`, `profiles`, `pairings`, `devices`, `api_keys`, `payments`, `slots`, `events`, `deliveries`. Sirf `settings` dikhna complete setup nahi hai. Agar console poori file execute na kare toh complete statements ek-ek karke run karo.

Ye schema fresh database mein chalana hai. Agar isi FFSHOP schema ka setup pehle partially run hua ho, updated script dobara run kar sakte ho: existing objects skip honge aur missing objects banenge. Existing payment database delete/reset mat karna. Ye kisi doosre app ya purane incompatible schema ko migrate nahi karta. Existing Go/Oracle version ka database is schema se automatically migrate nahi hota.

## 4. Pages site upload karo

1. **Workers & Pages → Create application → Pages → Direct Upload / Upload assets**.
2. Unique project name choose karo, jaise **ffshop-yourname**.
3. **pages-upload.zip** upload karke deploy karo.
4. Address milega, jaise `https://ffshop-yourname.pages.dev`.
5. Abhi app “Complete Cloudflare setup first” bol sakta hai; agla step zaroori hai.

Pages choose karna, generic Worker asset-upload flow nahi. Package mein compiled `_worker.js` hai; Pages dashboard direct upload is mode ko support karta hai.

## 5. Database binding aur settings lagao

Pages project → **Settings**, production environment:

| Setting | Value |
|---|---|
| D1 database binding name | `DB` (capital letters) |
| D1 database | Step3 wala `ffshop` |
| Environment variable `PUBLIC_ORIGIN` | Apna exact `https://ffshop-yourname.pages.dev` |
| Secret `ADMIN_KEY_HASH` | Step2 wala hash |

PUBLIC_ORIGIN mein aakhir ka `/`, `/payment` path ya preview deployment address mat lagana. ADMIN_KEY_HASH mein login key ki jagah **hash** lagana. D1 binding **DB** hona chahiye, sirf text variable nahi.

Settings save karne ke baad same **pages-upload.zip** ka naya production deployment karo, taaki bindings/settings apply hon. Phir apni production site kholo aur **Admin key** se login karo.

## 6. Automatic maintenance Worker

1. Cloudflare mein alag **Worker** banao: **ffshop-maintenance**.
2. Uske code editor ka starter code poora replace karke **maintenance-worker.js** paste karo. Deploy/save karo.
3. Worker → Settings/Bindings → D1 binding: naam **DB**, same **ffshop** database.
4. Worker → Settings → Triggers / Cron Triggers → schedule **`*/5 * * * *`** add karo.
5. Save/deploy karo. Schedule apply hone mein kuch minutes lag sakte hain.

Is Worker ko ADMIN_KEY_HASH nahi chahiye. Worker URL kholne se sirf text aata hai; actual work scheduled event karta hai. Ye expired order cleanup aur shop webhook retries chalata hai. Customer page phone event aate hi paid status dekh sakta hai; use cron ka wait nahi karna padta. Shop webhook ke pehle attempt mein lagbhag5minutes lag sakte hain.

## 7. Merchant QR destination save karo

1. FFSHOP dashboard mein Paytm Business / PhonePe Business / HDFC SmartHub Vyapar / BharatPe select karo.
2. **Apne merchant QR ka UPI ID** aur merchant name fill karo.
3. Save & use for new orders dabao.
4. Ek waqt mein ek profile new orders ke liye active hai. Baaki profiles ke existing orders apna original destination rakhte hain.

Kisi aur ki example UPI ID mat use karna. QR mein jo recipient hai, paired phone ki business app mein wahi merchant account hona chahiye. Ek app mein multiple merchant accounts/branches ki mixed notifications supported nahi hain.

## 8. Phone connect karo

1. Android8+ par **ffshop-relay-1.3.apk** install karo. Android pooche toh is file source se installation allow karo.
2. Relay app mein Notification access on karo.
3. Battery/background restriction hatao; phone ka automatic date/time on rakho.
4. Relay mein apne business apps enable karo; extra apps default off ho sakte hain.
5. FFSHOP dashboard → Create pairing link.
6. Poora HTTPS link relay app mein paste karke pair karo; link5minutes mein expire hota hai aur ek baar use hota hai.
7. Dashboard refresh karke phone last contact aur notification access check karo.

Pairing link/private keys kisi customer ko mat bhejna. App bina customer UTR ke merchant notification bhejti hai; ye bank API ya official provider integration nahi hai.

## 9. Pehla REAL payment test — tab live jaana

1. Dashboard mein base amount ₹1 ya ₹10 ka test order banao.
2. FFSHOP jo exact amount de, jaise ₹10.37, wahi pay karo. Added paise matching ke liye hain; customer ko total pehle dikhaya jaata hai.
3. Dusre phone se QR scan karo ya payment page ka Open UPI app use karo.
4. Merchant business app mein **actual incoming credit** dekho.
5. Relay receipt aur website order paid hona verify karo. Customer page normally10seconds ke andar next poll par update karta hai, phone delivery delays alag ho sakti hain.
6. Har provider app ke saath alag real test karo. Synthetic tests mein pass hone ka matlab provider ke har current notification format ka verified support nahi hai.

Agar bank credit ho gaya lekin website pending hai: **dobara payment mat karwana**. App notification permissions, selected app, internet, time aur dashboard receipts dekho. Unknown/changed notification wording ko manually credit evidence se investigate karo. Hum us provider ki privacy-safe notification example dekhkar parser improve kar sakte hain.

## 10. Customer ko link bhejna / shop se jodna

Sabse simple: dashboard mein order banao aur customer ka **payment link** bhejo. Customer login ke bina QR aur status dekh sakta hai. Admin page, pairing link ya shop API key share mat karna.

Existing shop automatic checkout ke liye `cloudflare/README.md` mein API/webhook contract hai. API key sirf shop server par rakho. Product price server decide kare. Signed webhook ya authenticated GET status par payment ID aur order amount match karke fulfil karo; browser ke “paid” text ko delivery authority mat banao. Is package mein gaming diamonds/UC deliver karne ka supplier ya product-store checkout wiring included nahi hai.

## Limitations aur maintenance

- Payment window5minutes; posted-in-window notification ko deliver hone ke liye extra5minutes. Expired QR par pay na karein.
- Exact amount24hours reserve rehta hai, taaki old/duplicate notification new order se na mile. Busy price ranges mein capacity limit aa sakti hai.
- Matching notification-based hai; bank settlement-proof nahi. Unrelated same-amount incoming transfer false match kar sakta hai. Dedicated merchant collection account aur reconciliation use karo.
- Free hosting quota limited hai. Polling aur SQL bhi quota consume karte hain. Cloudflare dashboard usage dekho; request/CPU limit par service fail ho sakti hai. Paid plans automatically enable nahi kiye gaye.
- D1 export/backups apne Cloudflare account se regularly lo. Site update karte waqt database preserve karo.
- Admin key lost: fresh key generate karke ADMIN_KEY_HASH badlo, D1 `sessions` table clear karo, redeploy karo. Customer data tables clear mat karna.
- Source and upstream license included hain. Editable source apna maintain kar sakte ho; upstream attribution/license preserve karo.

**Verification:** 18 automated tests (payment integration, database setup recovery and actual Pages asset routing), TypeScript and production build passed locally. Live Cloudflare deployment, remote CPU/quota behavior, actual Android phone and real merchant payments not yet verified. CodeRabbit review task setting se disabled tha. Shared-browser check sandbox permission error se blocked tha.

## ERR_TOO_MANY_REDIRECTS aaye toh

2026-09-30 ka routing fix included hai. Pehle app `/index.html` asset maang rahi thi; Pages usse `/` par redirect karta tha, jisse loop banta tha. Updated code canonical `/` asset ko serve karta hai.

Existing Pages project → Deployments → Create a new deployment → Production → updated pages-upload.zip → Save and Deploy. Deployment successful hone ke baad site ko Incognito window mein kholo, taaki purana permanent redirect cache use na ho. Isi project ki DB binding aur settings use hongi; database initialization dobara chalana is routing fix ki requirement nahi hai.


## Phone Enabled hai, lekin app “Connect your server first” kehti hai

Purane Cloudflare build mein device ID UUID thi; Relay APK ko 64-character hex ID chahiye. Server phone add karta tha, lekin APK response reject karke pairing save nahi karti thi. Latest Pages ZIP mein yeh fix hai.

1. Existing Pages project mein latest Pages ZIP ka Production deployment upload karo. Database dobara initialize mat karo.
2. Dashboard refresh karo. Failed pairing wali old phone entry ko Revoke phone karo.
3. Create pairing link dabao. Pura naya private link Relay ke Paste HTTPS pairing link field mein paste karo; sirf website address nahi.
4. 1. Connect my FFSHOP server dabao, apna server address check karo aur Connect dabao. Link 5 minutes mein expire hota hai; turant use karo.
5. Notification access allow karo, Paytm Business select rakho, aur 4. Start relay / retry connection dabao.
6. Dashboard Refresh par Last contact aana chahiye. Agar nahi aaye, Relay ka Last server result aur error text copy karo. Pairing link/admin key share mat karo.

Existing APK usable hai. Purani payment automatically recover hone ki guarantee nahi: enrollment se purani notifications capture nahi hoti. Pehle heartbeat confirm karo; paid order ko merchant transaction history se reconcile karo.


## Paytm notification mein amount dikh raha hai, lekin receipt ignored hai

Relay 1.3 same signing key aur package ke saath update hai; 1.1 uninstall mat karo. Update install karke Start relay dabao. Paytm notification panel mein rehne do, phir Inspect active merchant notifications dabao. Yeh sirf enabled merchant apps ke active Title, Text, Big text, custom layout aur capture eligibility dikhata hai. Yeh action details ko store/send nahi karta aur payment dobara process nahi karta. Text long-press karke copy kar sakte ho; share karne se pehle personal details hide karo.

Relay1.3 Paytm ke custom layout ke visible text ko padhne ki koshish karta hai jab standard Text/Big text empty hon. Inspector mein Custom text dekho. Agar woh bhi empty/error ho, current capture amount read nahi kar paaya. Screenshot se iski guarantee nahi ki ja sakti. Latest Cloudflare build Paytm ke limited Hindi receipt template `₹<amount> <sender> से प्राप्त हुआ` ko accept karta hai jab woh captured text mein mile; negative/ambiguous messages reject hote hain. Exact amount, order timing aur device signature checks unchanged hain. ₹1 sample kisi adjusted checkout total ko settle nahi karega. Purane delivered ignored events automatically replay nahi hote. Real-phone capture/matching abhi user verification maangta hai.


### Custom text check: nayi payment ki zarurat nahi

Existing app par ffshop-relay-1.3.apk update install karo; uninstall/re-pair mat karo. Start relay aur Inspect active merchant notifications kholo. Existing Paytm payment notification clear mat karo. Eligible non-summary entry ke Custom text mein amount/message dekho. Error ya empty result ho toh uska text share karo, personal details hide karke. ₹1 sample ka ignored rehna expected hai; usse kisi pending adjusted-total order ko paid nahi karna hai.
