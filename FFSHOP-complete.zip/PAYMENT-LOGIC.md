# Payment logic and reference-site findings

## FFSHOP Cloudflare

1. The operator or authenticated shop server creates an order; anonymous customers cannot choose an amount and mint arbitrary merchant orders.
2. A unique payable amount is reserved in D1; retrying the same idempotency key returns the original order.
3. Public checkout renders the exact total and merchant UPI QR, and polls read-only status. Opening an app or clicking a button never marks an order paid.
4. The owner's paired Android phone listens only to selected supported business packages and signs an event with its Keystore P-256 key.
5. Server checks pairing, epoch, signature, timestamp, event identity, package, incoming-payment text, amount and order time window.
6. A D1 transaction matches the correct merchant profile and amount, marks the order paid exactly once and queues the signed shop callback atomically.
7. A scheduled Worker retries failed callbacks. The shop must verify HMAC, order/payment identity and amount, and deduplicate before fulfilment.

Proof boundary: signed phone notification ≠ signed bank receipt. No merchant bank API key is used. Real merchant format and delivery validation is required. Same-amount correlation cannot mathematically identify the payer's intended order if an unrelated transfer coincides. Do not promise bank-grade settlement guarantees.

## https://top-up-crazy.com/payment

Checked public GET HTML on2026-09-30; GET returned200 (HEAD returned404). No order was created and no payment submitted.

Observed in its public JavaScript:

- Product/game and package selection, player ID and optional server/region.
- Reads `/api/games`, `/api/games/{gameId}/packages` and `/api/verification-config?game_id=...` to populate/adjust its interface.
- A player-verification flow references `/api/verify-player`.
- `proceedToPay()` builds FormData containing `game_id`, `package_id`, `player_id`, optional `server_region`.
- It POSTs those values to `/api/payment/generate-qr`.
- On `result.success`, the browser navigates to the server's `result.redirect_url`.

This supports a server-created payment/redirect flow. The supplied URL did not expose the backend source, authenticated gateway configuration, bank callbacks or post-payment matching logic. It does **not** establish whether that site's backend uses a licensed gateway API, merchant app notifications, UTR review or another mechanism. Its exact automatic-verification method and authenticity remain unverified. No security audit or endorsement of that merchant is implied.

FFSHOP includes its own QR and order-status flow; it does not copy this site's branding/assets or claim to reproduce its private verification code.
